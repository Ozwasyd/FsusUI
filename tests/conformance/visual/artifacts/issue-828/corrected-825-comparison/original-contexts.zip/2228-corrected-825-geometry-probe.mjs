import { chromium } from '/workspace/FsusUI-828-consume-825-corrected/node_modules/@playwright/test/index.mjs';
import { writeFileSync } from 'node:fs';
const browser=await chromium.launch({headless:true});
const observations=[];
for (const [source,baseURL] of [['9dadbc7320f80ebc2c2e6f88905e97f4784e5cdd','http://127.0.0.1:5333'],['6ddb84c8b5c1b0ae69b1ded4f54bd32553e8e1a3','http://127.0.0.1:5334']]) {
 for (const [width,height,locale,theme] of [[390,844,'default','light'],[320,640,'default','light'],[375,812,'long','light'],[375,812,'long','dark']]) {
  const context=await browser.newContext({viewport:{width,height},hasTouch:true,locale:'zh-CN',colorScheme:theme});
  const page=await context.newPage();
  const path='/?audit=ui-states&markdownEditorTransaction=1'+(locale==='long'?'&markdownCommandSurfaces=1&markdownLocale=long':'')+(theme==='dark'?'&theme=dark':'');
  await page.goto(baseURL+path,{waitUntil:'domcontentloaded'});
  const fixture=page.getByTestId('markdown-editor-transaction-fixture');
  await fixture.waitFor(); await page.evaluate(()=>document.fonts.ready);
  const commands=fixture.locator('.el-markdown-editor__commands'); const more=fixture.locator('.el-markdown-editor__command-more');
  await commands.evaluate(el=>{el.scrollIntoView({block:'center',inline:'nearest'});el.scrollLeft=0});
  const geometry=await more.evaluate(el=>{
   const target=el.getBoundingClientRect(), group=el.closest('.el-markdown-editor__command-groups')?.getBoundingClientRect(), scroller=el.parentElement.querySelector('.el-markdown-editor__commands').getBoundingClientRect();
   const x=(Math.max(target.left,0)+Math.min(target.right,innerWidth))/2,y=(Math.max(target.top,0)+Math.min(target.bottom,innerHeight))/2;
   const hit=document.elementFromPoint(x,y);
   return {oldTestClosestCommands:el.closest('.el-markdown-editor__commands')!==null,trigger:target.toJSON(),commands:scroller.toJSON(),group:group?.toJSON(),directlyTappable:hit===el||el.contains(hit),accessibleLabel:el.getAttribute('aria-label'),resolvedTheme:document.documentElement.getAttribute('data-theme-resolved')};
  });
  const focus=[];
  if(locale==='long'){
   const buttons=commands.getByRole('button'); await buttons.first().focus();
   for(let i=0;i<await buttons.count();i++){
    const b=buttons.nth(i);
    focus.push(await b.evaluate(el=>{const a=el.getBoundingClientRect(),s=el.parentElement.getBoundingClientRect();return{focused:document.activeElement===el,minimumWidth:parseFloat(getComputedStyle(el).minInlineSize),visibleWidth:Math.max(0,Math.min(a.right,s.right,innerWidth)-Math.max(a.left,s.left,0))}}));
    await b.press('Tab');
   }
  }
  observations.push({source,baseURL,path,viewport:{width,height},geometry,focus});
  await context.close();
 }
}
await browser.close();
writeFileSync('/tmp/2228-corrected-825-geometry-observed.json',JSON.stringify({qualificationEligible:false,diagnosticOnly:true,observations},null,2));
console.log(JSON.stringify(observations.map(x=>({source:x.source,width:x.viewport.width,locale:x.path,commands:x.geometry.commands.width,trigger:x.geometry.trigger.width,oldClosest:x.geometry.oldTestClosestCommands,directlyTappable:x.geometry.directlyTappable,focus:x.focus})),null,2));

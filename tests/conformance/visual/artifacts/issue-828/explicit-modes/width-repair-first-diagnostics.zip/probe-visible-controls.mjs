import{chromium}from'@playwright/test';import{readFile,writeFile,mkdir}from'node:fs/promises';import{execFileSync}from'node:child_process';
const head=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),browser=await chromium.launch(),rows=[],critical=await readFile('vue/packages/theme-chalk/dist/el-public-shell-critical.css','utf8');
for(const theme of ['light','dark'])for(const [width,height] of [[844,390],[667,375],[736,320],[932,430],[1024,520]])for(const zoom of [1,1.5,2])for(const nav of ['menu','inline','bottom','none']){
 const p=await browser.newPage({viewport:{width,height},hasTouch:true});await p.emulateMedia({reducedMotion:'reduce'});await p.goto(`http://127.0.0.1:5355/?visual=public-shell-nav-mode&theme=${theme}&contract=1&session=anonymous&navMode=${nav}`);await p.evaluate(()=>document.fonts.ready);await p.evaluate(z=>document.documentElement.style.zoom=String(z),zoom);
 for(const state of ['collapsed','search-expanded']){
  if(state==='search-expanded')await p.locator('.el-public-shell__mobile-search-trigger').click();
  for(const style of ['full','critical-only']){
   if(style==='critical-only')await p.evaluate(css=>{for(const s of document.styleSheets)s.disabled=true;const el=document.createElement('style');el.id='visible-critical';el.textContent=css;document.head.append(el)},critical);
   await p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
   const controls=await p.evaluate(()=>{
    const box=el=>{let r=el.getBoundingClientRect(),x=r.x,y=r.y,right=r.right,bottom=r.bottom;for(let a=el.parentElement;a;a=a.parentElement){const s=getComputedStyle(a),b=a.getBoundingClientRect();if(/hidden|clip|auto|scroll/.test(s.overflowX)){x=Math.max(x,b.left);right=Math.min(right,b.right)}if(/hidden|clip|auto|scroll/.test(s.overflowY)){y=Math.max(y,b.top);bottom=Math.min(bottom,b.bottom)}}return{x,y,width:Math.max(0,right-x),height:Math.max(0,bottom-y)}};
    return [...document.querySelectorAll('[data-public-shell-header] a,[data-public-shell-header] button,[data-public-shell-header] summary,[data-public-shell-header] input[type=text]')].filter(el=>el.getClientRects().length).map(el=>{const b=box(el),x=b.x+b.width/2,y=b.y+b.height/2,hit=document.elementFromPoint(x,y);return{tag:el.tagName,label:el.getAttribute('aria-label')??el.textContent.trim(),classes:el.className,visible:b,centerInViewport:x>=0&&x<innerWidth&&y>=0&&y<innerHeight,centerHit:el.contains(hit)}})
   });
   const reach=[];if(nav==='inline')for(const link of await p.locator('.el-public-shell__mobile-nav-link').all()){
    await link.focus();await link.evaluate(el=>el.scrollIntoView({block:'nearest',inline:'center'}));reach.push(await link.evaluate(el=>{const r=el.getBoundingClientRect(),nav=el.parentElement.getBoundingClientRect(),x=Math.max(r.x,nav.x),right=Math.min(r.right,nav.right),cx=(x+right)/2,cy=r.y+r.height/2;return{label:el.textContent.trim(),rect:{x:r.x,y:r.y,width:r.width,height:r.height},visibleWidth:Math.max(0,right-x),hit:el.contains(document.elementFromPoint(cx,cy)),focused:document.activeElement===el,scrollLeft:el.parentElement.scrollLeft}}));
   }
   rows.push({theme,width,height,zoom,nav,state,style,controls,reach});
   if(style==='critical-only')await p.evaluate(()=>{document.querySelector('#visible-critical').remove();for(const s of document.styleSheets)s.disabled=false});
  }
  if(state==='search-expanded')await p.locator('.el-public-shell__mobile-search-trigger').click();
 }
 await p.close();console.log(theme,width,height,zoom,nav)
}
await browser.close();await mkdir('.tmp/issue-828-explicit/after-widths',{recursive:true});await writeFile('.tmp/issue-828-explicit/after-widths/visible-controls-first.json',JSON.stringify({head,qualificationEligible:false,method:'Actual original fixture controls, ancestor overflow clipping, elementFromPoint and native focus/scrollIntoView; visible control sizes retained without relaxing44px; critical-only not full theme parity',rows},null,2)+'\n');console.log(JSON.stringify({rows:rows.length,unhittable:rows.flatMap(r=>r.controls.filter(c=>c.visible.width&&c.visible.height&&c.centerInViewport&&!c.centerHit).map(c=>({row:r,label:c.label}))).length,reachFailures:rows.flatMap(r=>r.reach.filter(c=>!c.hit||!c.focused)).length}));

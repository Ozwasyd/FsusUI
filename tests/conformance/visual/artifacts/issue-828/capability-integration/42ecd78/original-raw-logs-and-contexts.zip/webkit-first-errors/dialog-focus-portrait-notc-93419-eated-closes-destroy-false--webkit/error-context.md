# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: dialog-focus.spec.ts >> portrait-notch390x844 dark >> returns to actual pointer trigger on repeated closes (destroy=false)
- Location: vue/tests/dialog-focus/dialog-focus.spec.ts:21:11

# Error details

```
Error: browserType.launch: 
╔══════════════════════════════════════════════════════╗
║ Host system is missing dependencies to run browsers. ║
║ Missing libraries:                                   ║
║     libGLESv2.so.2                                   ║
╚══════════════════════════════════════════════════════╝
```
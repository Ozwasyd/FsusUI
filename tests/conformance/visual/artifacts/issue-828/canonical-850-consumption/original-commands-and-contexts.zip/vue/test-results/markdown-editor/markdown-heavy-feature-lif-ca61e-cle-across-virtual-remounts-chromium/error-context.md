# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: markdown-heavy-feature-lifecycle.spec.ts >> bounds mixed heavy feature lifecycle across virtual remounts
- Location: vue/tests/markdown-editor/markdown-heavy-feature-lifecycle.spec.ts:288:5

# Error details

```
Error: Timeout 20000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- main [ref=e3]:
  - article [ref=e4]:
    - paragraph [ref=e6]: Paragraph 2954 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e8]: Paragraph 2955 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e10]: Paragraph 2956 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e12]: Paragraph 2957 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e14]: Paragraph 2958 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e16]: Paragraph 2959 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e18]: Paragraph 2960 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e20]: Paragraph 2961 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e22]: Paragraph 2962 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e24]: Paragraph 2963 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e26]: Paragraph 2964 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e28]: Paragraph 2965 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e30]: Paragraph 2966 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e32]: Paragraph 2967 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e34]: Paragraph 2968 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e36]: Paragraph 2969 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e38]: Paragraph 2970 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e40]: Paragraph 2971 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e42]: Paragraph 2972 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e44]: Paragraph 2973 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e46]: Paragraph 2974 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e48]: Paragraph 2975 with stable lifecycle filler text and Unicode 中文.
    - paragraph [ref=e50]: Paragraph 2976 with stable lifecycle filler text and Unicode 中文.
```

# Test source

```ts
  304 |     .poll(async () => (await readMetrics(page))?.cacheEntries ?? 0, {
  305 |       timeout: 60_000,
  306 |     })
  307 |     .toBeGreaterThan(0)
  308 |   await expect
  309 |     .poll(async () =>
  310 |       Object.keys((await readMetrics(page))?.identities ?? {}).sort(),
  311 |     )
  312 |     .toEqual(['code-highlight', 'latex', 'mermaid'])
  313 | 
  314 |   const initial = await readMetrics(page)
  315 |   expect(initial).toMatchObject({
  316 |     active: 0,
  317 |     retainedListeners: 0,
  318 |     retainedObservers: 0,
  319 |     retainedResources: 0,
  320 |     retainedRuntimes: 0,
  321 |     retainedTasks: 0,
  322 |   })
  323 |   expect(initial!.cacheEntries).toBeLessThanOrEqual(128)
  324 |   expect(initial!.cacheBytes).toBeLessThanOrEqual(4 * 1024 * 1024)
  325 |   expect(initial!.identities['code-highlight']).toMatchObject({
  326 |     config: '{}',
  327 |     theme: 'light',
  328 |   })
  329 |   expect(initial!.identities.latex).toMatchObject({
  330 |     theme: 'token-bound',
  331 |   })
  332 |   expect(initial!.identities.mermaid?.config).toContain('"tokens"')
  333 |   expect(initial!.scheduler).toMatchObject({
  334 |     authority: 'markdown-editor-frame-scheduler@1',
  335 |   })
  336 |   expect(initial!.scheduler.mutateCommits).toBeGreaterThan(0)
  337 |   expect(initial!.scheduler.postPaintCommits).toBe(
  338 |     initial!.scheduler.mutateCommits,
  339 |   )
  340 |   const initialCodeNodeId = initial!.identities['code-highlight']!.nodeId
  341 |   const initialMountedUnits = await renderer
  342 |     .locator('[data-fsus-render-unit]')
  343 |     .count()
  344 |   expect(initialMountedUnits).toBeLessThan(3000)
  345 | 
  346 |   await renderer.evaluate((element) => {
  347 |     element.scrollTop = element.scrollHeight
  348 |     element.dispatchEvent(new Event('scroll'))
  349 |   })
  350 |   await expect
  351 |     .poll(async () => (await readMetrics(page))?.unmounted ?? 0, {
  352 |       timeout: 60_000,
  353 |     })
  354 |     .toBeGreaterThan(0)
  355 |   await expect
  356 |     .poll(async () => (await readMetrics(page))?.active ?? -1, {
  357 |       timeout: 60_000,
  358 |     })
  359 |     .toBe(0)
  360 |   const afterBottom = await readMetrics(page)
  361 |   expect(afterBottom!.cacheEntries).toBeLessThanOrEqual(128)
  362 |   expect(afterBottom!.cacheBytes).toBeLessThanOrEqual(4 * 1024 * 1024)
  363 |   expect(afterBottom).toMatchObject({
  364 |     retainedListeners: 0,
  365 |     retainedObservers: 0,
  366 |     retainedResources: 0,
  367 |     retainedRuntimes: 0,
  368 |     retainedTasks: 0,
  369 |   })
  370 | 
  371 |   await renderer.evaluate((element) => {
  372 |     element.scrollTop = 0
  373 |     element.dispatchEvent(new Event('scroll'))
  374 |   })
  375 |   await expect
  376 |     .poll(async () => (await readMetrics(page))?.reuses ?? 0)
  377 |     .toBeGreaterThan(0)
  378 |   await expect.poll(async () => (await readMetrics(page))?.active ?? -1).toBe(0)
  379 | 
  380 |   const settledCycles: Array<{ cacheBytes: number; cacheEntries: number }> = []
  381 |   for (let cycle = 0; cycle < 3; cycle += 1) {
  382 |     for (const position of ['bottom', 'top'] as const) {
  383 |       await renderer.evaluate((element, nextPosition) => {
  384 |         element.scrollTop = nextPosition === 'bottom' ? element.scrollHeight : 0
  385 |         element.dispatchEvent(new Event('scroll'))
  386 |       }, position)
  387 |       await page.evaluate(
  388 |         () =>
  389 |           new Promise<void>((resolve) => {
  390 |             let frames = 0
  391 |             const next = () => {
  392 |               frames += 1
  393 |               if (frames >= 4) resolve()
  394 |               else requestAnimationFrame(next)
  395 |             }
  396 |             requestAnimationFrame(next)
  397 |           }),
  398 |       )
  399 |       await expect
  400 |         .poll(async () => (await readMetrics(page))?.active ?? -1, {
  401 |           timeout: 60_000,
  402 |         })
  403 |         .toBe(0)
> 404 |       await expect
      |       ^ Error: Timeout 20000ms exceeded while waiting on the predicate
  405 |         .poll(async () => (await readMetrics(page))?.retainedResources ?? -1)
  406 |         .toBe(0)
  407 |       const settled = (await readMetrics(page))!
  408 |       settledCycles.push({
  409 |         cacheBytes: settled.cacheBytes,
  410 |         cacheEntries: settled.cacheEntries,
  411 |       })
  412 |     }
  413 |   }
  414 |   expect(
  415 |     settledCycles.every(
  416 |       ({ cacheBytes, cacheEntries }) =>
  417 |         cacheEntries <= 128 && cacheBytes <= 4 * 1024 * 1024,
  418 |     ),
  419 |   ).toBe(true)
  420 |   expect(
  421 |     settledCycles.some(
  422 |       (entry, index) =>
  423 |         index > 0 &&
  424 |         entry.cacheEntries <= settledCycles[index - 1]!.cacheEntries &&
  425 |         entry.cacheBytes <= settledCycles[index - 1]!.cacheBytes,
  426 |     ),
  427 |   ).toBe(true)
  428 | 
  429 |   const beforeIdle = (await readMetrics(page))!
  430 |   await page.evaluate(
  431 |     () =>
  432 |       new Promise<void>((resolve) => {
  433 |         let frames = 0
  434 |         const next = () => {
  435 |           frames += 1
  436 |           if (frames >= 30) resolve()
  437 |           else requestAnimationFrame(next)
  438 |         }
  439 |         requestAnimationFrame(next)
  440 |       }),
  441 |   )
  442 |   const afterIdle = (await readMetrics(page))!
  443 |   expect(afterIdle).toMatchObject({
  444 |     activations: beforeIdle.activations,
  445 |     retainedListeners: 0,
  446 |     retainedObservers: 0,
  447 |     retainedResources: 0,
  448 |     retainedRuntimes: 0,
  449 |     retainedTasks: 0,
  450 |     reuses: beforeIdle.reuses,
  451 |   })
  452 |   expect(
  453 |     await page.locator('iframe[data-fsus-markdown-heavy-work]').count(),
  454 |   ).toBe(0)
  455 | 
  456 |   const repeatedCodePrefix = [
  457 |     '```typescript',
  458 |     'const repeatedHeavyNode: number = 1',
  459 |     '```',
  460 |     '',
  461 |     '```typescript',
  462 |     'const repeatedHeavyNode: number = 1',
  463 |     '```',
  464 |     '',
  465 |   ].join('\n')
  466 |   await transition(page, {
  467 |     codeHighlight: true,
  468 |     documentEpoch: 1,
  469 |     documentKey: 'heavy-document-a',
  470 |     revision: 2,
  471 |     sourcePrefix: repeatedCodePrefix,
  472 |     theme: 'light',
  473 |   })
  474 |   await expect
  475 |     .poll(async () => (await readMetrics(page))?.identity?.revision)
  476 |     .toBe('heavy-lifecycle-2')
  477 |   await expect
  478 |     .poll(
  479 |       async () =>
  480 |         (await readMetrics(page))?.projectionNodeIds['code-highlight']
  481 |           ?.length ?? 0,
  482 |     )
  483 |     .toBeGreaterThanOrEqual(3)
  484 |   const repeatedCodeNodeIds = (await readMetrics(page))!.projectionNodeIds[
  485 |     'code-highlight'
  486 |   ]!
  487 |   expect(repeatedCodeNodeIds[0]).not.toBe(repeatedCodeNodeIds[1])
  488 |   expect(repeatedCodeNodeIds).toContain(initialCodeNodeId)
  489 | 
  490 |   await transition(page, {
  491 |     codeHighlight: true,
  492 |     documentEpoch: 1,
  493 |     documentKey: 'heavy-document-a',
  494 |     revision: 3,
  495 |     sourcePrefix: `Stable prefix inserted before repeated technical nodes.\n\n${repeatedCodePrefix}`,
  496 |     theme: 'light',
  497 |   })
  498 |   let afterSourceRevision: LifecycleMetrics | undefined
  499 |   await expect
  500 |     .poll(async () => {
  501 |       const snapshot = await readMetrics(page)
  502 |       if (
  503 |         snapshot?.identity?.revision !== 'heavy-lifecycle-3' ||
  504 |         snapshot.active !== 0 ||
```